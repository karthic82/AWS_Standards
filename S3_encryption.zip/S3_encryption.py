import boto3
import json

def s3_encryption_fun(bucket_name):
	client = boto3.client('s3')

	response = client.put_bucket_encryption(
	    Bucket=bucket_name,
	    
	    ServerSideEncryptionConfiguration={
	        'Rules': [
	            {
	                'ApplyServerSideEncryptionByDefault': {
	                    'SSEAlgorithm': 'AES256'
	                }
	            }
	        ]
	    }
	)
	print ("S3 Encryption done")

def lambda_handler(event,context):

	s3_client = boto3.client('s3')
	modified_message = json.loads(event['Records'][0]['Sns']['Message'])
	aws_region = modified_message['detail']['awsRegion']

	try:
		if 'bucketName' in modified_message['detail']['requestParameters']:
			bucket_name = modified_message['detail']['requestParameters']['bucketName']
			s3_encryption_fun(bucket_name)
			
	except Exception as e:
		print (e)
	